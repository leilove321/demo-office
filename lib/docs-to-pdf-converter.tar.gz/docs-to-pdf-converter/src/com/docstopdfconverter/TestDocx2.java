///*
// * Copyright(C) 2019 FUYUN DATA SERVICES CO.,LTD. - All Rights Reserved
// * Unauthorized copying of this file, via any medium is strictly prohibited
// * Proprietary and confidential
// * 该源代码版权归属福韵数据服务有限公司所有
// * 未经授权，任何人不得复制、泄露、转载、使用，否则将视为侵权
// */
//
//package com.docstopdfconverter;
//
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.xhtmlrenderer.pdf.ITextFontResolver;
//import org.xhtmlrenderer.pdf.ITextRenderer;
//
//import com.itextpdf.text.pdf.BaseFont;
//
//import fr.opensagres.poi.xwpf.converter.core.FileImageExtractor;
//import fr.opensagres.poi.xwpf.converter.core.FileURIResolver;
//import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLConverter;
//import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLOptions;
//
//public class TestDocx2 {
//
//	public static void main(String[] args) {
//		String docFile = "/home/fuyun/vm_share/1.docx";
//		File picturesDir = new File("/home/fuyun/vm_share/images/");
//		String contents = null;
//
//		try (InputStream is = new FileInputStream(docFile)) {
//			XWPFDocument document = new XWPFDocument(is);
//			XHTMLOptions options = XHTMLOptions.create();
//			options.setExtractor(new FileImageExtractor(picturesDir));
//			options.URIResolver(new FileURIResolver(picturesDir));
//
//			ByteArrayOutputStream baos = new ByteArrayOutputStream();
//			XHTMLConverter.getInstance().convert(document, baos, options);
//			contents = baos.toString();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		System.out.println(contents);
//		Document doc = Jsoup.parse(contents);
//		contents = doc.html();
//		contents = contents.replaceAll("<br>", "<br/>");
//		contents = contents.replaceAll("&nbsp;", " ");
//		System.out.println(contents);
//
//		try (OutputStream outStream = new FileOutputStream("/home/fuyun/vm_share/1.pdf");) {
//			ITextRenderer renderer = new ITextRenderer();
//            ITextFontResolver fontResolver = renderer.getFontResolver();
//            // 设置中文字体/宋体
//            fontResolver.addFont("net/sf/jasperreports/fonts/dejavu/simsun.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
//            // 获取HTML文件的URL
////            String url = new File(HTML).toURI().toURL().toString();
//            // 方式一/URL方式生成PDF
////            renderer.setDocument(url);
//            // 方式二/HTML代码字符串方式生成PDF
//            // HTML代码字符串
//            renderer.setDocumentFromString(contents);
//            renderer.layout();
//            renderer.createPDF(outStream);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//}
