///*
// * Copyright(C) 2019 FUYUN DATA SERVICES CO.,LTD. - All Rights Reserved
// * Unauthorized copying of this file, via any medium is strictly prohibited
// * Proprietary and confidential
// * 该源代码版权归属福韵数据服务有限公司所有
// * 未经授权，任何人不得复制、泄露、转载、使用，否则将视为侵权
// */
//
//package com.docstopdfconverter;
//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//import org.docx4j.Docx4J;
//import org.docx4j.convert.out.FOSettings;
//import org.docx4j.fonts.IdentityPlusMapper;
//import org.docx4j.fonts.Mapper;
//import org.docx4j.fonts.PhysicalFont;
//import org.docx4j.fonts.PhysicalFonts;
//import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
//
//public class TestDocToPDF {
//
//	public static void main(String[] args) throws Exception {
//		try (InputStream iStream = new FileInputStream("/home/fuyun/vm_share/1.docx");
//				OutputStream outStream = new FileOutputStream("/home/fuyun/vm_share/1.pdf");) {
//
//			//WordprocessingMLPackage mlPackage = Doc.convert(iStream);
//			WordprocessingMLPackage mlPackage = WordprocessingMLPackage.load(iStream);  
//			Mapper fontMapper = new IdentityPlusMapper();  
//            //中文字体转换
////            fontMapper.put("华文行楷", PhysicalFonts.get("STXingkai"));  
////            fontMapper.put("隶书", PhysicalFonts.get("LiSu"));
////            fontMapper.put("宋体",PhysicalFonts.get("SimSun"));
////            fontMapper.put("微软雅黑",PhysicalFonts.get("Microsoft Yahei"));
////            fontMapper.put("黑体",PhysicalFonts.get("SimHei"));
////            fontMapper.put("楷体",PhysicalFonts.get("KaiTi"));
////            fontMapper.put("新宋体",PhysicalFonts.get("NSimSun"));
////            fontMapper.put("华文行楷", PhysicalFonts.get("STXingkai"));
////            fontMapper.put("华文仿宋", PhysicalFonts.get("STFangsong"));
////            fontMapper.put("宋体扩展",PhysicalFonts.get("simsun-extB"));
////            fontMapper.put("仿宋",PhysicalFonts.get("FangSong"));
////            fontMapper.put("仿宋_GB2312",PhysicalFonts.get("FangSong_GB2312"));
////            fontMapper.put("幼圆",PhysicalFonts.get("YouYuan"));
////            fontMapper.put("华文宋体",PhysicalFonts.get("STSong"));
////            fontMapper.put("华文中宋",PhysicalFonts.get("STZhongsong"));
//            PhysicalFonts.addPhysicalFonts("SimSun", TestDocToPDF.class.getResource("/net/sf/jasperreports/fonts/dejavu/simsun.ttf"));
//            //宋体&新宋体
//            PhysicalFont simsunFont = PhysicalFonts.get("SimSun");
//            fontMapper.put("SimSun", simsunFont); 
//            mlPackage.setFontMapper(fontMapper);  
//            
//      
////            PdfConversion conversion = new org.docx4j.convert.out.pdf.viaXSLFO.Conversion(mlPackage);  
////            conversion.output(outStream, new PdfSettings());  
//			FOSettings foSettings = Docx4J.createFOSettings();
//			foSettings.setWmlPackage(mlPackage);
//			Docx4J.toFO(foSettings, outStream, Docx4J.FLAG_EXPORT_PREFER_XSL);
//			// Docx4J.toPDF(mlPackage, outStream);
//
//		} finally {
//			// TODO: handle finally clause
//		}
//
//	}
//
//}
