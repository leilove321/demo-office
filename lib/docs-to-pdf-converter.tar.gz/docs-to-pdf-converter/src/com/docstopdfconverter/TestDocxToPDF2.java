/*
 * Copyright(C) 2019 FUYUN DATA SERVICES CO.,LTD. - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * 该源代码版权归属福韵数据服务有限公司所有
 * 未经授权，任何人不得复制、泄露、转载、使用，否则将视为侵权
 */

package com.docstopdfconverter;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.lowagie.text.Font;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;

import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;
import fr.opensagres.xdocreport.itext.extension.IPdfWriterConfiguration;
import fr.opensagres.xdocreport.itext.extension.font.IFontProvider;

public class TestDocxToPDF2 {

	public static void main(String[] args) throws Exception {
		try (InputStream iStream = new FileInputStream("/home/fuyun/vm_share/12.docx");
				OutputStream outStream = new FileOutputStream("/home/fuyun/vm_share/1.pdf");) {

			XWPFDocument document = new XWPFDocument(iStream);
			
			// https://blog.csdn.net/zk_spring/article/details/43412221
			// https://blog.csdn.net/weixin_37848710/article/details/89522862
			// https://download.csdn.net/download/qq_37487977/10590139

			PdfOptions options = PdfOptions.create().fontEncoding( "windows-1250" );
			options.fontProvider(new IFontProvider() {

				@Override
				public Font getFont(String familyName, String encoding, float size, int style, Color color) {
					com.lowagie.text.pdf.BaseFont bfChinese = null;
					try {
//						bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);// jar包
						 bfChinese=BaseFont.createFont("net/sf/jasperreports/fonts/dejavu/simsun.ttf",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);
						/// home/fuyun/git/docs-to-pdf-converter/src/com/docstopdfconverter
//						bfChinese=BaseFont.createFont("/home/fuyun/git/docs-to-pdf-converter/src/com/docstopdfconverter/simsun.ttc,0",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED); 
					} catch (Exception e) {
						e.printStackTrace();
					}
					Font font = new Font(bfChinese, size, style, color);
					font.setColor(color);

					return font;
				}
			});

			options.setConfiguration(new IPdfWriterConfiguration() {
				
				@Override
				public void configure(PdfWriter writer) {
					System.out.println(writer.getPageNumber());
					
				}
			});
			PdfConverter.getInstance().convert(document, outStream, options);

		}

	}

}
