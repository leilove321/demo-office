///*
// * Copyright(C) 2019 FUYUN DATA SERVICES CO.,LTD. - All Rights Reserved
// * Unauthorized copying of this file, via any medium is strictly prohibited
// * Proprietary and confidential
// * 该源代码版权归属福韵数据服务有限公司所有
// * 未经授权，任何人不得复制、泄露、转载、使用，否则将视为侵权
// */
//
//package com.docstopdfconverter;
//
//import com.itextpdf.text.BaseColor;
//import com.itextpdf.text.Font;
//import com.itextpdf.text.pdf.BaseFont;
//import com.itextpdf.tool.xml.XMLWorkerFontProvider;
//
//public class SimsunFontProvider extends XMLWorkerFontProvider {
//	@Override
//	public Font getFont(String fontname, String encoding, boolean embedded, float size, int style, BaseColor color) {
//		// return super.getFont(fontname, encoding, embedded, size, style, color);
//		BaseFont bfChinese = null;
//		try {
////			bfChinese=BaseFont.createFont("STSongStd-Light","UniGB-UCS2-H",BaseFont.NOT_EMBEDDED);//jar包
//			bfChinese = BaseFont.createFont("net/sf/jasperreports/fonts/dejavu/simsun.ttf", BaseFont.IDENTITY_H,
//					BaseFont.NOT_EMBEDDED);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		Font font = new Font(bfChinese, size, style, color);
//		font.setColor(color);
//
//		return font;
//	}
//}
