///*
// * Copyright(C) 2019 FUYUN DATA SERVICES CO.,LTD. - All Rights Reserved
// * Unauthorized copying of this file, via any medium is strictly prohibited
// * Proprietary and confidential
// * 该源代码版权归属福韵数据服务有限公司所有
// * 未经授权，任何人不得复制、泄露、转载、使用，否则将视为侵权
// */
//
//package com.docstopdfconverter;
//
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.io.OutputStream;
//import java.nio.charset.StandardCharsets;
//
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//
//import com.itextpdf.text.BaseColor;
//import com.itextpdf.text.Font;
//import com.itextpdf.text.FontProvider;
//import com.itextpdf.text.pdf.BaseFont;
//import com.itextpdf.text.pdf.PdfWriter;
//import com.itextpdf.tool.xml.XMLWorkerHelper;
//
//import fr.opensagres.poi.xwpf.converter.core.FileImageExtractor;
//import fr.opensagres.poi.xwpf.converter.core.FileURIResolver;
//import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLConverter;
//import fr.opensagres.poi.xwpf.converter.xhtml.XHTMLOptions;
//
//public class TestDocx {
//
//	public static void main(String[] args) {
//		String docFile = "/home/fuyun/vm_share/2.docx";
//		File picturesDir = new File("/home/fuyun/vm_share/images/");
//		String contents = null;
//
//		try (InputStream is = new FileInputStream(docFile)) {
//			XWPFDocument document = new XWPFDocument(is);
//			XHTMLOptions options = XHTMLOptions.create();
//			options.setExtractor(new FileImageExtractor(picturesDir));
//			options.URIResolver(new FileURIResolver(picturesDir));
//
//			ByteArrayOutputStream baos = new ByteArrayOutputStream();
//			XHTMLConverter.getInstance().convert(document, baos, options);
//			contents = baos.toString();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		System.out.println(contents);
//		Document doc = Jsoup.parse(contents);
//		contents = doc.html();
//		contents = contents.replaceAll("<br>", "<br/>");
//		System.out.println(contents);
//
//		try (OutputStream outStream = new FileOutputStream("/home/fuyun/vm_share/2.pdf");) {
//			com.itextpdf.text.Document pdfDoc = new com.itextpdf.text.Document();
//			PdfWriter writer = PdfWriter.getInstance(pdfDoc, outStream);
//			pdfDoc.open();
//			XMLWorkerHelper.getInstance().parseXHtml(writer, pdfDoc, new ByteArrayInputStream(contents.getBytes("utf-8")),
//					StandardCharsets.UTF_8, new FontProvider() {
//
//						@Override
//						public boolean isRegistered(String fontname) {
//							return true;
//						}
//
//						@Override
//						public Font getFont(String fontname, String encoding, boolean embedded, float size, int style,
//								BaseColor color) {
//							BaseFont bfChinese = null;
//							try {
////								bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
////										BaseFont.NOT_EMBEDDED);// jar包
//								bfChinese = BaseFont.createFont("net/sf/jasperreports/fonts/dejavu/simsun.ttf",
//										BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
//							} catch (Exception e) {
//								e.printStackTrace();
//							}
//							Font font = new Font(bfChinese, size, style, color);
//							font.setFamily("Courier");
//							font.setColor(color);
//
//							return font;
//						}
//					});
//			pdfDoc.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//}
